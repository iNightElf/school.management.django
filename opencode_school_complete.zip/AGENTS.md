
# AGENTS.md

## Project
School Management System
Stack:
- React + TypeScript
- Django + DRF
- PostgreSQL

## Architecture
- Clean Architecture
- Service Layer Pattern
- Thin Views / Controllers
- Business Logic in Services
- Full Audit Trail

## Roles
Admin, Coordinator, Teacher, Accountant, Parent

## Financial Rules
- Financial records are immutable.
- Never edit ledger history.
- Corrections require reversal entries.
- Store Transaction Date and Entry Timestamp separately.
- All transactions must be auditable.

## Student Rules
- Unique Student ID
- Unique Admission Number
- No hard delete if financial history exists

## Fee Rules
- Regular Fees
- Optional Fees
- Waivers (fixed/percentage)
- Approval tracking required

## Excel Import Workflow
Upload → Preview → Validate → Error Review → Confirm → Import

## UI Rules
Every table must support:
- Search
- Filter
- Pagination
- Export

## Development Workflow
1. Analyze existing architecture
2. Consider permissions
3. Consider database impact
4. Consider performance
5. Implement
6. Verify
